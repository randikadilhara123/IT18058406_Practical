//Response-Alert  
$(document).ready(function() {
    if ($("#alertSuccess").text().trim() == "") {
        $("#alertSuccess").hide();
    }
    $("#alertError").hide();
});
//Valid Input Checker
function validateCForm() {

    var phone_regx = /^[+]*[(]{0,1}[0-9]{1,3}[)]{0,1}[-\s\./0-9]*$/g;

    if ($("#CNameF").val().trim() == "") {
        return "Customer Must Have A First Name";
    }
    if ($("#CNameL").val().trim() == "") {
        return "Customer Must Have A Last Name";
    }
    if ($("#CNumber").val().trim() == "") {
        return "Customer Must Have A Phone Number";
    }
    if (!phone_regx.test($("#CNumber").val().trim())) {
        return "Incorrect Phone Number Format";
    }
    if ($("#CStatus").val().trim() == "") {
        return "Status Can't be Empty";
    }
    
    return true;
}
//Save
$(document).on("click", "#btnSave", function(event) {
    //Clear alerts
    $("#alertSuccess").text("");
    $("#alertError").text("");
    $("#alertSuccess").hide();
    $("alertError").hide();
    //Form validation
    var status = validateDocForm();
    if (status != true) {
        $("#alertError").text(status);
        $("#alertError").show();
        return;
    }

    var method = ($("#CIdSave").val() == "") ? "POST" : "PUT";
    
    $.ajax({
        url: "customerAPI",
        type: method,
        data: $("#formDoc").serialize(),
        dataType: "text",
        complete: function(response, status) {
        	
            onCustomerSaveSuccess(response.responseText, status);
        }
    });
});

function onCustomerSaveSuccess(response, status) {
    if (status == "success") {
    	
        var resultset = JSON.parse(response);
        
        if (resultset.status.trim() == "success") {
            $("#alertSuccess").text("Saved Successfully!");
            $("#alertSuccess").show;
            $("#divCGrid").html(resultset.data);

        } else if (resultset.status.trim() == "error") {
            $("#alertError").text(resultset.data);
            $("#alertError").show();
        }
    } else if (status == "error") {
        $("#alertError").text("Saving Error!");
        $("#alertError").show();
    } else {
        $("#alertError").text("Unkown Error while Saving!");
        $("#alertError").show();
    }
    $("#CIdSave").val("");
    $("#formDoc")[0].reset();
}
//Update Customer
$(document).on("click", "#btnUpdate", function(event) {
	console.log("Update Button Invoked");
    $("#CIdSave").val($(this).closest("tr").find('#hiddenCIDUpdate').val());
    $("#CNameF").val($(this).closest("tr").find('td:eq(0)').text());
    $("#CNameM").val($(this).closest("tr").find('td:eq(1)').text());
    $("#CNameL").val($(this).closest("tr").find('td:eq(2)').text());
    $("#CNumber").val($(this).closest("tr").find('td:eq(3)').text());
    $("#CStatus").val($(this).closest("tr").find('td:eq(4)').text());
});
//Remove Customer
$(document).on("click", "#btnRemove", function(event) {
    $.ajax({
        url: "customerAPI",
        type: "DELETE",
        data: "C_id=" + $(this).data("Cid"),
        dataType: "text",
        complete: function(response, status) {
            onCustomerDeleteSuccess(response.responseText, status);
        }
    })
});

function onCustomerDeleteSuccess(response, status) {
    if (status == "success") {
        var resultset = JSON.parse(response);
        if (resultset.status.trim() == "success") {
            $("#alertSuccess").text("Deleted Successfully!");
            $("#alertSuccess").show;
            $("#divDocGrid").html(resultset.data);

        } else if (resultset.status.trim() == "error") {
            $("#alertError").text(resultset.data);
            $("#alertError").show();
        }
    } else if (status == "error") {
        $("#alertError").text("Deleting Error!");
        $("#alertError").show();
    } else {
        $("#alertError").text("Unkown Error while Deleting!");
        $("#alertError").show();
    }
}