package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import util.DBConnection;

public class customer {

	public customer() {

	}

	// Doctor Table
	public String readCustomers() {
		String out = "";
		Connection connection = DBConnection.getConnection();
		out = "<table border='1'><tr><th>First Name</th><th>Middle Name</th><th>Last Name</th><th>Contact</th><th>Status</th><th>Update</th><th>Remove</th></tr>";

		String query = "SELECT * FROM customer";
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			ResultSet resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				String did = Integer.toString(resultSet.getInt("id"));
				String fname = resultSet.getString("firstname");
				String mname = resultSet.getString("middlename");
				String lname = resultSet.getString("lastname");
				String contact = resultSet.getString("contact");
				String status = resultSet.getString("status");

				out += "<tr>";

				out += "<td><input type='hidden' id='hiddendocIDUpdate' name='hiddendocIDUpdate' value='" + did
						+ "'/>"+fname+"</td>";
//				out += "<td>" + fname + "</td>";
				out += "<td>" + mname + "</td>";
				out += "<td>" + lname + "</td>";
				out += "<td>" + contact + "</td>";
				out += "<td>" + status + "</td>";

				out += "<td><input id='btnUpdate' name='btnUpdate' type='button' value='Update' class='btn btn-secondary'></td>"

						+ "<td><input id='btnRemove' name='btnRemove' type='button' value='Remove' class='btn btn-danger' data-docid='"
						+ did + "'>";
				
				out += "</td>";
				out += "</tr>";
				
			}
			

			out += "</table>";
			connection.close();
		} catch (Exception e) {
			out = "Reading Interrupted by Error! ";
			System.err.println(e.getMessage());
		}
		
		return out;
	}
	
	public String insertCustomer(String fName,String mName,String lName, String number, String status ) {
		String out="";
		Connection connection = DBConnection.getConnection();
		String query = "INSERT INTO `customer`" + "(`firstname`,`middlename`,`lastname`,`contact`,`status`)"
				+ "values (?,?,?,?,?)";
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(query);

			preparedStatement.setString(1, fName);
			preparedStatement.setString(2, mName);
			preparedStatement.setString(3, lName);
			preparedStatement.setString(4, number);
			preparedStatement.setString(5, status);

			preparedStatement.execute();
			connection.close();
			String newCustomer = readCustomer();
			out="{\"status\":\"success\", \"data\": \"" + newCustomer + "\"}";
		} catch (Exception e) {
			out="{\"status\":\"error\", \"data\": \"Error While Inserting The Customer!\"}";
			System.err.println(e.getMessage());
		}
		return out;
	}
	
	public String updateCustomer(String did,String fName,String mName,String lName, String number, String status  ) {
		String out="";
		Connection connection = DBConnection.getConnection();
		String query = "UPDATE `customer` SET"
				+ " `firstname` = ?, `middlename` = ?, `lastname` = ? , `contact` = ?, `status` = ?" + "WHERE id = ?";
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(query);

			preparedStatement.setString(1, fName);
			preparedStatement.setString(2, mName);
			preparedStatement.setString(3, lName);
			preparedStatement.setString(4, number);
			preparedStatement.setString(5, status);

			preparedStatement.setInt(6, Integer.parseInt(did));
			preparedStatement.execute();
			connection.close();
			String updatedCustomer = readCustomer();
			out="{\"status\":\"success\", \"data\": \"" + updatedCustomer + "\"}";
		} catch (Exception e) {
			out="{\"status\":\"error\", \"data\": \"Error While Updating Customer ID = "+did+"!\"}";
			System.err.println(e.getMessage());
		}
		return out;
		
	}
	
	public String deleteCustomer(String did) {
		String out="";
		Connection connection = DBConnection.getConnection();
	
		String query = "DELETE FROM customer WHERE id = ?";
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, Integer.parseInt(did));
			preparedStatement.execute();
			connection.close();
			String remainCustomers = readCustomer();
			out="{\"status\":\"success\", \"data\": \"" + remainCustomer + "\"}";
		} catch (Exception e) {
			out="{\"status\":\"error\", \"data\": \"Error While Deleting Customer ID = "+did+"!\"}";
			System.err.println(e.getMessage());
		}
		return out;
	}
}
